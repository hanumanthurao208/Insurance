﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace MvcApplication1.Models
{
    public class HealthDb:DbContext
    {
        public HealthDb() : base("name = DBcon") { }

        public DbSet<Health> HealthReport { get; set; }
    }
}