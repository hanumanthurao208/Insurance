﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MvcApplication1.Models
{
    public class Health
    {
        public int Id { get; set; }
        public string Sugar { get; set; }
        public string Lungs { get; set; }
        public string Heart { get; set; }
       [DisplayFormat(DataFormatString = "{0:d/M/yyy}", ApplyFormatInEditMode = true)]
        public DateTime Date { get; set; }
        public int clientId { get; set; }
        public string MailId { get; set; }


    }
}