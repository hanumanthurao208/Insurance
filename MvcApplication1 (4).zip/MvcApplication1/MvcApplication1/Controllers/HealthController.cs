﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;
using System.Net.Mail;
using System.Net;
using System.Text;

namespace MvcApplication1.Controllers
{
    public class HealthController : Controller
    {

        HealthDb db = new HealthDb();
     

        public ActionResult Index()
        {


            var list = from C in db.HealthReport
                       group C by C.clientId
                           into groups
                           select groups.OrderByDescending(x => x.Date.Year).ThenByDescending(x => x.Date.Month).ThenByDescending(x => x.Date.Day).FirstOrDefault();

              

            return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Health model)
        {
            db.HealthReport.Add(model);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
     
        public ActionResult Send(int? id)
        {
            Health model = db.HealthReport.Find(id);
            bool RESULT = false;

            string body = "Hi Sir/Madam, <br> your id is:" + model.clientId + ". Verify your reopors <br><br>";
            body = body+"  Sugar: " + model.Sugar + "<br>    Lungs: "+model.Lungs+"<br>  Heart:"+model.Heart;
           
            RESULT = SendMail(model.MailId, "Reports", body);
            if (RESULT == true)
            {
                ViewBag.message = "Mail Sent Successfully";
                return RedirectToAction("Index");
            }
            else 

            {
                ViewBag.message = "Mail Not Sent";
                return RedirectToAction("Index");
            }
           
           
        }

        public bool SendMail(string toMail,string Subject,string Body)
        {
            try
            {
                string SenderMail = System.Configuration.ConfigurationManager.AppSettings["SenderMail"].ToString();
                string SenderPwd = System.Configuration.ConfigurationManager.AppSettings["SenderPwd"].ToString();

                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.EnableSsl = true;
                client.Timeout = 100000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential(SenderMail,SenderPwd);
                MailMessage mailmessage = new MailMessage(SenderMail,toMail,Subject,Body);
                mailmessage.IsBodyHtml = true;
                mailmessage.BodyEncoding = UTF8Encoding.UTF8;
                client.Send(mailmessage);

                return true;



            }
            catch (Exception e)
            {
                TempData["error"] = e.Message;
                return false;
            }
            
        }
        public ActionResult Details(int? id)
        {
            Health hlt = (db.HealthReport.Where(e => e.Id == id)).FirstOrDefault();


            return View(hlt);
        }
        public ActionResult Edit(int? id)
        {
            Health hlt = (db.HealthReport.Where(e => e.Id == id)).FirstOrDefault();


            return View(hlt);
        }
        [HttpPost]
        public ActionResult Edit(Health model)
        {
            db.Entry(model).CurrentValues.SetValues(model);
            db.SaveChanges();


            return View(model);
        }
        public ActionResult Search()
        {
          return View();
        }
        [HttpPost]
        public ActionResult Search(Health model)
        {
            List<Health> modl = db.HealthReport.Where(e => e.clientId == model.clientId).OrderByDescending(x => x.Date.Year).ThenByDescending(x => x.Date.Month).ThenByDescending(x => x.Date.Day).ToList();
            return View("Search_Result",modl);
        }
    }
}
